# SCA & Supply Chain Labs (syft, grype, trivy)

Projetos **intencionalmente vulneráveis** para praticar SCA e análise de Supply Chain.
Use apenas em ambientes de laboratório.

## Estrutura
- `python-vuln/` — Flask antigo, libs vulneráveis, Ubuntu 18.04 (EOL)
- `node-vuln/` — Express antigo, lodash/minimist/serialize-javascript vulneráveis, Node 10 (EOL)
- `java-vuln/` — Log4j 2.14.1 (vulnerável), JRE 8 slim

## Build das imagens
```bash
# Python
docker build -t vuln-python:latest python-vuln

# Node.js
docker build -t vuln-node:latest node-vuln

# Java (Maven multi-stage)
docker build -t vuln-java:latest java-vuln
```

## Syft — gerar SBOM (CycloneDX JSON)
```bash
syft vuln-python:latest -o cyclonedx-json > python-sbom.cdx.json
syft vuln-node:latest   -o cyclonedx-json > node-sbom.cdx.json
syft vuln-java:latest   -o cyclonedx-json > java-sbom.cdx.json
```

## Grype — varredura de vulnerabilidades
```bash
# Imagem diretamente
grype vuln-python:latest
grype vuln-node:latest
grype vuln-java:latest

# A partir de SBOM
grype sbom:python-sbom.cdx.json
grype sbom:node-sbom.cdx.json
grype sbom:java-sbom.cdx.json
```

## Trivy — image, filesystem e SBOM
```bash
# Imagem
trivy image vuln-python:latest
trivy image vuln-node:latest
trivy image vuln-java:latest

# Diretório (FS) — pega dependências + config + secrets
trivy fs python-vuln
trivy fs node-vuln
trivy fs java-vuln

# SBOM (CycloneDX gerado pelo Syft)
trivy sbom python-sbom.cdx.json
trivy sbom node-sbom.cdx.json
trivy sbom java-sbom.cdx.json
```

## Dicas
- Atualize os bancos de dados antes de rodar: `grype db update` e `trivy --download-db-only` (ou `trivy image --download-db-only`).
- Para enriquecer os achados, rode as imagens em bases antigas/EOL (já incluído) e **não** faça `apt-get upgrade`.
- Você pode alterar versões no `requirements.txt`, `package.json` e `pom.xml` para observar o impacto nas detecções.
```)

